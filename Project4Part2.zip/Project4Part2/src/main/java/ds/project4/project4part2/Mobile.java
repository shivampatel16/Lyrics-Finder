package ds.project4.project4part2;

public class Mobile {
    protected String mobile_model;


    protected String mobile_brand;

    protected String request_timestamp;

    protected String request_song_name;

    protected String request_artist_name;

    protected String response_song_name;

    protected String response_artist_name;

    protected String lyrics;

    protected String response_timestamp;

    protected int status_code;

    protected double latency;

    // Constructor to initialize the values of the instance variables
    public Mobile(String mobile_model, String mobile_brand, String request_timestamp, String request_song_name, String request_artist_name, String response_song_name, String response_artist_name, String lyrics, String response_timestamp, double latency, int status_code) {
        this.mobile_model = mobile_model;
        this.mobile_brand = mobile_brand;
        this.request_timestamp = request_timestamp;
        this.request_song_name = request_song_name;
        this.request_artist_name = request_artist_name;
        this.response_song_name = response_song_name;
        this.response_artist_name = response_artist_name;
        this.lyrics = lyrics;
        this.response_timestamp = response_timestamp;
        this.latency = latency;
        this.status_code = status_code;
    }
}

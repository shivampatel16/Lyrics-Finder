package ds.project4.project4part2;

public class API {
    protected String request_timestamp;

    protected String request_song_name;

    protected String request_artist_name;

    protected String response_song_name;

    protected String response_artist_name;

    protected String lyrics;

    protected String response_timestamp;

    protected int status_code;

    protected double latency;

    public API(String request_timestamp, String request_song_name, String request_artist_name, String response_song_name, String response_artist_name, String lyrics, String response_timestamp, int status_code, double latency) {
        this.request_timestamp = request_timestamp;
        this.request_song_name = request_song_name;
        this.request_artist_name = request_artist_name;
        this.response_song_name = response_song_name;
        this.response_artist_name = response_artist_name;
        this.lyrics = lyrics;
        this.response_timestamp = response_timestamp;
        this.status_code = status_code;
        this.latency = latency;
    }
}

package ds.project4.project4part2;

import com.google.gson.Gson;

public class ResponseMessage {

    protected String artistName;
    protected String songName;
    protected String lyrics;

    // Constructor to initialize the values of the instance variables
    ResponseMessage(String artistName, String songName, String lyrics) {
        this.artistName = artistName;
        this.songName = songName;
        this.lyrics = lyrics;
    }

    /***
     * The method converts the ResponseMessage object to a JSON String using Gson.
     * @return JSON String representation of the ResponseMessage object
     */
    public java.lang.String toString() {

        // Create a Gson object
        Gson gson = new Gson();

        // Serialize to JSON
        return gson.toJson(this);
    }
}

package ds.project4.project4part2;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.LoggerContext;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.*;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Sorts;
import org.bson.Document;
import org.json.JSONObject;
import org.slf4j.LoggerFactory;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;

import static com.mongodb.client.model.Aggregates.*;
import static com.mongodb.client.model.Projections.exclude;
import static com.mongodb.client.model.Projections.fields;

public class LyricsFinderModel {
    /*
     * Make an HTTP request to a given URL
     *
     * @param urlString The URL of the request
     * @return A string of the response from the HTTP GET.  This is identical
     * to what would be returned from using curl on the command line.
     */
    public String fetchAPI(String urlString) {
        String response = "";
        try {
            URL url = new URL(urlString);
            /*
             * Create an HttpURLConnection.  This is useful for setting headers
             * and for getting the path of the resource that is returned (which
             * may be different than the URL above if redirected).
             * HttpsURLConnection (with an "s") can be used if required by the site.
             */
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response += str;
            }
            in.close();
        } catch (IOException e) {
            System.out.println("Eeek, an exception");
            // Do something reasonable.  This is left for students to do.
        }
        return response;
    }

    public MongoClient connectToMongoDB() {
        ((LoggerContext) LoggerFactory.getILoggerFactory()).getLogger("org.mongodb.driver").setLevel(Level.ERROR);
        ConnectionString connectionString = new ConnectionString("mongodb://ShivamGautamDSProject4:ShivamGautamDSProject4@ac-d1nwlm4-shard-00-00.tsumdav.mongodb.net:27017, ac-d1nwlm4-shard-00-01.tsumdav.mongodb.net:27017,ac-d1nwlm4-shard-00-02.tsumdav.mongodb.net:27017/?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1");
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .serverApi(ServerApi.builder()
                        .version(ServerApiVersion.V1)
                        .build())
                .build();
        MongoClient mongoClient = MongoClients.create(settings);
        return mongoClient;
    }

    public void mobileInsertOne(Mobile mobile, MongoCollection<Document> mobileCollection){
        Document mobileDoc = new Document();
        mobileDoc.append("lyrics", mobile.lyrics);
        mobileDoc.append("mobile_brand", mobile.mobile_brand);
        mobileDoc.append("mobile_model", mobile.mobile_model);
        mobileDoc.append("latency", mobile.latency);
        mobileDoc.append("status_code", mobile.status_code);
        mobileDoc.append("request_artist_name", mobile.request_artist_name);
        mobileDoc.append("request_song_name", mobile.request_song_name);
        mobileDoc.append("request_timestamp", mobile.request_timestamp);
        mobileDoc.append("response_timestamp", mobile.response_timestamp);
        mobileDoc.append("response_artist_name", mobile.response_artist_name);
        mobileDoc.append("response_song_name", mobile.response_song_name);
        mobileCollection.insertOne(mobileDoc);
    }

    public void apiInsertOne(API api, MongoCollection<Document> apiCollection){
        Document apiDoc = new Document();
        apiDoc.append("lyrics", api.lyrics);
        apiDoc.append("request_artist_name", api.request_artist_name);
        apiDoc.append("request_song_name", api.request_song_name);
        apiDoc.append("request_timestamp", api.request_timestamp);
        apiDoc.append("status_code", api.status_code);
        apiDoc.append("response_timestamp", api.response_timestamp);
        apiDoc.append("response_artist_name", api.response_artist_name);
        apiDoc.append("response_song_name", api.response_song_name);
        apiDoc.append("latency", api.latency);
        apiCollection.insertOne(apiDoc);
    }

    public JSONObject getMobileData(MongoCollection<Document> mobileCollection) {
        FindIterable<Document> mobileDocs = mobileCollection.find();
        JSONObject allData = new JSONObject();
        int i = 1;
        for (Document document : mobileDocs) {
            JSONObject documentObject = new JSONObject();
            documentObject.put("lyrics", document.getString("lyrics"));
            documentObject.put("mobile_brand", document.getString("mobile_brand"));
            documentObject.put("mobile_model", document.getString("mobile_model"));
            documentObject.put("latency", document.getDouble("latency"));
            documentObject.put("status_code", document.getInteger("status_code"));
            documentObject.put("request_artist_name", document.getString("request_artist_name"));
            documentObject.put("request_song_name", document.getString("request_song_name"));
            documentObject.put("request_timestamp", document.getString("request_timestamp"));
            documentObject.put("response_timestamp", document.getString("response_timestamp"));
            documentObject.put("response_artist_name", document.getString("response_artist_name"));
            documentObject.put("response_song_name", document.getString("response_song_name"));
            allData.put(String.valueOf(i), documentObject);
            i++;
        }
        return allData;
    }

    public JSONObject getAPIData(MongoCollection<Document> apiCollection){
        FindIterable<Document> apiDocs = apiCollection.find();
        JSONObject allData = new JSONObject();
        int i = 1;
        for (Document document : apiDocs) {
            JSONObject documentObject = new JSONObject();
            documentObject.put("lyrics", document.getString("lyrics"));
            documentObject.put("request_timestamp", document.getString("request_timestamp"));
            documentObject.put("response_timestamp", document.getString("response_timestamp"));
            documentObject.put("response_artist_name", document.getString("response_artist_name"));
            documentObject.put("response_song_name", document.getString("response_song_name"));
            documentObject.put("latency", document.getDouble("latency"));
            documentObject.put("status_code", document.getInteger("status_code"));
            documentObject.put("request_artist_name", document.getString("request_artist_name"));
            documentObject.put("request_song_name", document.getString("request_song_name"));
            allData.put(String.valueOf(i), documentObject);
            i++;
        }
        return allData;
    }

    public JSONObject getTopTenSongs(MongoCollection<Document> mobileCollection) {

        // Source: https://www.baeldung.com/java-mongodb-aggregations
        AggregateIterable<Document> topTenSongsDocs = mobileCollection.aggregate(Arrays.asList(
                group("$response_song_name", Accumulators.sum("count", 1)),
                sort(Sorts.descending("count")), limit(10)));
        JSONObject allData = new JSONObject();
        int i = 1;
        for (Document document : topTenSongsDocs) {
            JSONObject documentObject = new JSONObject();
            documentObject.put("song_name", document.getString("_id"));
            documentObject.put("number_of_searches", document.getInteger("count").toString());
            allData.put(String.valueOf(i), documentObject);
            i++;
        }
        return allData;
    }

    public JSONObject getTopTenArtists(MongoCollection<Document> mobileCollection){

        // Source: https://www.baeldung.com/java-mongodb-aggregations
        AggregateIterable<Document> topTenArtistsDocs = mobileCollection.aggregate(Arrays.asList(
                group("$response_artist_name", Accumulators.sum("count", 1)),
                sort(Sorts.descending("count")), limit(10)));
        JSONObject allData = new JSONObject();
        int i = 1;
        for (Document document : topTenArtistsDocs) {
            JSONObject documentObject = new JSONObject();
            documentObject.put("artist_name", document.getString("_id"));
            documentObject.put("number_of_searches", document.getInteger("count").toString());
            allData.put(String.valueOf(i), documentObject);
            i++;
        }
        return allData;
    }

    public double getAverageLatency(MongoCollection<Document> collection) {

        // Source: https://www.baeldung.com/java-mongodb-aggregations
        AggregateIterable<Document> averageLatencyDoc = collection.aggregate(Arrays.asList(group(null, Accumulators.avg("latency", "$latency")), project(fields(exclude("_id")))));
        double avgLatency = 0.0;
        for (Document document : averageLatencyDoc) {
            avgLatency = document.getDouble("latency");
        }
        return avgLatency;
    }

    public JSONObject getTopFivePhones(MongoCollection<Document> mobileCollection) {

        // Source: https://www.baeldung.com/java-mongodb-aggregations
        AggregateIterable<Document> topFivePhonesDocs = mobileCollection.aggregate(Arrays.asList(new Document("$group",
                        new Document("_id",
                                new Document("brand", "$mobile_brand")
                                        .append("model", "$mobile_model"))
                                .append("count",
                                        new Document("$sum", 1))),
                new Document("$sort",
                        new Document("count", -1)),
                new Document("$project",
                        new Document("brand", "$_id.brand")
                                .append("model", "$_id.model")
                                .append("_id", 0)
                                .append("count", 1)),
                new Document("$limit", 5)));
        JSONObject allData = new JSONObject();
        int i = 1;
        for (Document document : topFivePhonesDocs) {
            JSONObject documentObject = new JSONObject();
            documentObject.put("mobile_brand", document.getString("brand"));
            documentObject.put("mobile_model", document.getString("model"));
            documentObject.put("number_of_requests", document.getInteger("count").toString());
            allData.put(String.valueOf(i), documentObject);
            i++;
        }
        return allData;
    }
}

package ds.project4.project4part2;

import java.io.*;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet(name = "lyricsFinderServlet", value = "/getLyrics")
public class LyricsFinderServlet extends HttpServlet {
    private String message;

    LyricsFinderModel lyricsFinderModel = new LyricsFinderModel();

    public void init() {
        message = "Hello World!";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //response.setContentType("text/html");

        //String androidRequest = "http://localhost:8080/getLyrics?artistName=<artistName>&songName=<songName>&phoneBrand=<phoneBrand>&phoneDevice=<phoneDevice>";

        System.out.println("doGet is called");

        String artistName = request.getParameter("artistName");
        String songName = request.getParameter("songName");
        String phoneBrand = request.getParameter("phoneBrand");
        String phoneDevice = request.getParameter("phoneDevice");
        String api_key = "4794d71e3256361ba03a768912556bc9";
        String lyrics = "";

        String apiURLString = "https://api.vagalume.com.br/search.php?art="
                + artistName + "&mus="
                + songName + "&apikey="
                + api_key;

        String jsonAPIReply  = lyricsFinderModel.fetchAPI(apiURLString);

        JSONObject jsonObject = new JSONObject(jsonAPIReply);

        JSONArray jsonArray = jsonObject.getJSONArray("mus"); // notice that `"posts": [...]`

        for (int i = 0; i < jsonArray.length(); i++)
        {
            String lyrics_line = jsonArray.getJSONObject(i).getString("text");
            lyrics = lyrics + lyrics_line;
        }

        ResponseMessage responseMessage = new ResponseMessage(artistName, songName, lyrics);

        // https://www.baeldung.com/servlet-json-response

        PrintWriter out = response.getWriter();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        out.print(responseMessage);
        out.flush();

        // Hello
        //PrintWriter out = response.getWriter();
        //out.println("<html><body>");
        //out.println("<h1>" + message + "</h1>");
        //out.println("</body></html>");


    }

    public void destroy() {
    }
}
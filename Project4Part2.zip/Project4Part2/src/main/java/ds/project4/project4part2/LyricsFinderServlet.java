package ds.project4.project4part2;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import java.util.TimeZone;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet(name = "lyricsFinderServlet",
        urlPatterns = {"/getLyrics", "/getDashboard"}) //servlet handles two url endpoints)
public class LyricsFinderServlet extends HttpServlet {
    private String message;

    LyricsFinderModel lyricsFinderModel = new LyricsFinderModel();

    public void init() {
        message = "Hello World!";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        // Source for compatability of different devices: CMU 95702 Fall 2022 Lab2-InterestingPicture Code
        // Used for compatability of the code on different devices

        // Determine what type of device our user is
        String ua = request.getHeader("User-Agent");

        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            /*
             * This is the latest XHTML Mobile doctype. To see the difference it
             * makes, comment it out so that a default desktop doctype is used
             * and view on an Android or iPhone.
             */
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }

        // https://www.baeldung.com/java-simple-date-format
        MongoClient mongoClient = lyricsFinderModel.connectToMongoDB();
        MongoDatabase LyricsFinderDB = mongoClient.getDatabase("LyricsFinderDB");

        MongoCollection<Document> mobileCollection = LyricsFinderDB.getCollection("MOBILE");

        MongoCollection<Document> apiCollection = LyricsFinderDB.getCollection("API");


        //check the request URL endpoint and make the appropriate method calls
        if (request.getServletPath().equals("/getLyrics")) {

            String mobile_request_timestamp = "", mobile_response_timestamp = "", api_request_timestamp = "", api_response_timestamp = "";
            String response_artistName = "", response_songName = "";
            double latency = 0.0;
            int statusCode = 200;


            TimeZone tz = TimeZone.getTimeZone("UTC");
            SimpleDateFormat sdf
                    = new SimpleDateFormat(
                    "dd-MM-yyyy HH:mm:ss.SSS");
            sdf.setTimeZone(tz);
            mobile_request_timestamp = sdf.format(new Date());

            String request_artistName = request.getParameter("artistName");
            String request_songName = request.getParameter("songName");
            String phoneBrand = request.getParameter("phoneBrand");
            String phoneDevice = request.getParameter("phoneDevice");
            String api_key = "4794d71e3256361ba03a768912556bc9";
            String lyrics = "";

            // https://www.baeldung.com/servlet-json-response
            PrintWriter out = response.getWriter();
            response.setContentType("application/json");
            response.setCharacterEncoding("UTF-8");

            if (Objects.equals(request_artistName, "") || Objects.equals(request_songName, "")) {
                ErrorResponseMessage errorResponseMessage = new ErrorResponseMessage("Song name and artist name cannot be empty!");

                API api = new API("", request_songName, request_artistName, "", "", "", "", 403, 0.0);
                lyricsFinderModel.apiInsertOne(api, apiCollection);

                Mobile mobile = new Mobile(phoneDevice, phoneBrand, mobile_request_timestamp, request_songName, request_artistName, "", "", "", "", 0.0, 403);
                lyricsFinderModel.mobileInsertOne(mobile, mobileCollection);

                response.sendError(HttpServletResponse.SC_FORBIDDEN);
                out.print(errorResponseMessage);
                out.flush();
            }

            String apiURLString = "https://api.vagalume.com.br/search.php?art="
                    + request_artistName + "&mus="
                    + request_songName + "&apikey="
                    + api_key;

            api_request_timestamp = sdf.format(new Date());

            String jsonAPIReply = lyricsFinderModel.fetchAPI(apiURLString);

            api_response_timestamp = sdf.format(new Date());

            JSONObject jsonObject = new JSONObject(jsonAPIReply);

            JSONObject artistInfo = jsonObject.getJSONObject("art");

            response_artistName = artistInfo.getString("name");


            // https://stackoverflow.com/questions/5015844/parsing-json-object-in-java

            JSONArray jsonArray = jsonObject.getJSONArray("mus");

            for (int i = 0; i < jsonArray.length(); i++) {
                String lyrics_line = jsonArray.getJSONObject(i).getString("text");
                lyrics = lyrics + lyrics_line;
                response_songName = jsonArray.getJSONObject(i).getString("name");
            }

            // https://www.baeldung.com/java-simple-date-format
            try {
                latency = sdf.parse(api_response_timestamp).getTime() - sdf.parse(api_request_timestamp).getTime();
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }

            API api = new API(api_request_timestamp, request_songName, request_artistName, response_songName, response_artistName, lyrics, api_response_timestamp, statusCode, latency);
            lyricsFinderModel.apiInsertOne(api, apiCollection);

            ResponseMessage responseMessage = new ResponseMessage(response_artistName, response_songName, lyrics);

            mobile_response_timestamp = sdf.format(new Date());

            try {
                latency = sdf.parse(mobile_response_timestamp).getTime() - sdf.parse(mobile_request_timestamp).getTime();
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }

            Mobile mobile = new Mobile(phoneDevice, phoneBrand, mobile_request_timestamp, request_songName, request_artistName, response_songName, response_artistName, lyrics, mobile_response_timestamp, latency, statusCode);
            lyricsFinderModel.mobileInsertOne(mobile, mobileCollection);

            out.print(responseMessage);
            out.flush();
        }
        else if (request.getServletPath().equals("/getDashboard")) {

            JSONObject mobileLogs = lyricsFinderModel.getMobileData(mobileCollection);
            request.setAttribute("mobileLogs", mobileLogs);

            JSONObject apiLogs = lyricsFinderModel.getAPIData(apiCollection);
            request.setAttribute("apiLogs", apiLogs);

            JSONObject topTenSongs = lyricsFinderModel.getTopTenSongs(mobileCollection);
            request.setAttribute("topTenSongs", topTenSongs);

            JSONObject topTenArtists = lyricsFinderModel.getTopTenArtists(mobileCollection);
            request.setAttribute("topTenArtists", topTenArtists);

            double avgLatencyAndroidApp = lyricsFinderModel.getAverageLatency(mobileCollection);
            request.setAttribute("avgLatencyAndroidApp", avgLatencyAndroidApp);

            double avgLatencyAPI = lyricsFinderModel.getAverageLatency(apiCollection);
            request.setAttribute("avgLatencyAPI", avgLatencyAPI);

            JSONObject topFivePhones = lyricsFinderModel.getTopFivePhones(mobileCollection);
            request.setAttribute("topFivePhones", topFivePhones);

            //transfer control to the view "result.jsp"
            RequestDispatcher view = request.getRequestDispatcher("dashboard.jsp");
            view.forward(request, response);

        }
    }

    public void destroy() {
    }
}
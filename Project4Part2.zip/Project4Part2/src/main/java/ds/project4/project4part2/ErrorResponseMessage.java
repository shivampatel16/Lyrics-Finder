package ds.project4.project4part2;

public class ErrorResponseMessage {
    protected String errorMessage;

    ErrorResponseMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}

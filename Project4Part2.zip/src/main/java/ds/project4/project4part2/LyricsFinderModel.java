package ds.project4.project4part2;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.LoggerContext;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.result.InsertOneResult;
import org.bson.Document;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class LyricsFinderModel {


    /*
     * Make an HTTP request to a given URL
     *
     * @param urlString The URL of the request
     * @return A string of the response from the HTTP GET.  This is identical
     * to what would be returned from using curl on the command line.
     */
    public String fetchAPI(String urlString) {
        String response = "";
        try {
            URL url = new URL(urlString);
            /*
             * Create an HttpURLConnection.  This is useful for setting headers
             * and for getting the path of the resource that is returned (which
             * may be different than the URL above if redirected).
             * HttpsURLConnection (with an "s") can be used if required by the site.
             */
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            // Read all the text returned by the server
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8"));
            String str;
            // Read each line of "in" until done, adding each to "response"
            while ((str = in.readLine()) != null) {
                // str is one line of text readLine() strips newline characters
                response += str;
            }
            in.close();
        } catch (IOException e) {
            System.out.println("Eeek, an exception");
            // Do something reasonable.  This is left for students to do.
        }
        return response;
    }

    public MongoClient connectToMongoDB() {
        ((LoggerContext) LoggerFactory.getILoggerFactory()).getLogger("org.mongodb.driver").setLevel(Level.ERROR);
        ConnectionString connectionString = new ConnectionString("mongodb://ShivamGautamDSProject4:ShivamGautamDSProject4@ac-d1nwlm4-shard-00-00.tsumdav.mongodb.net:27017, ac-d1nwlm4-shard-00-01.tsumdav.mongodb.net:27017,ac-d1nwlm4-shard-00-02.tsumdav.mongodb.net:27017/?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1");
        MongoClientSettings settings = MongoClientSettings.builder()
                .applyConnectionString(connectionString)
                .serverApi(ServerApi.builder()
                        .version(ServerApiVersion.V1)
                        .build())
                .build();
        MongoClient mongoClient = MongoClients.create(settings);
        return mongoClient;
    }

    public void mobileInsertOne(Mobile mobile, MongoCollection<Document> mobileCollection){
        Document mobileDoc = new Document();
        mobileDoc.append("lyrics", mobile.lyrics);
        mobileDoc.append("mobile_brand", mobile.mobile_brand);
        mobileDoc.append("mobile_model", mobile.mobile_model);
        mobileDoc.append("latency", mobile.latency);
        mobileDoc.append("status_code", mobile.status_code);
        mobileDoc.append("request_artist_name", mobile.request_artist_name);
        mobileDoc.append("request_song_name", mobile.request_song_name);
        mobileDoc.append("request_timestamp", mobile.request_timestamp);
        mobileDoc.append("response_timestamp", mobile.response_timestamp);
        mobileDoc.append("response_artist_name", mobile.response_artist_name);
        mobileDoc.append("response_song_name", mobile.response_song_name);
        mobileCollection.insertOne(mobileDoc);
    }

    public void apiInsertOne(API api, MongoCollection<Document> apiCollection){
        Document apiDoc = new Document();
        apiDoc.append("lyrics", api.lyrics);
        apiDoc.append("request_artist_name", api.request_artist_name);
        apiDoc.append("request_song_name", api.request_song_name);
        apiDoc.append("request_timestamp", api.request_timestamp);
        apiDoc.append("status_code", api.status_code);
        apiDoc.append("response_timestamp", api.response_timestamp);
        apiDoc.append("response_artist_name", api.response_artist_name);
        apiDoc.append("response_song_name", api.response_song_name);
        apiDoc.append("latency", api.latency);
        apiCollection.insertOne(apiDoc);
    }

//    public InsertOneResult insertOne(){
//        Document document = new Document();
//    }
}

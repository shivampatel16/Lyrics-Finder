package ds.project4.project4part2;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.result.InsertOneResult;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet(name = "lyricsFinderServlet", value = "/getLyrics")
public class LyricsFinderServlet extends HttpServlet {
    private String message;

    LyricsFinderModel lyricsFinderModel = new LyricsFinderModel();

    public void init() {
        message = "Hello World!";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String mobile_request_timestamp = "", mobile_response_timestamp = "", api_request_timestamp = "", api_response_timestamp = "";
        String response_artistName = "", response_songName = "";
        double latency = 0.0;
        int statusCode = 200;

        MongoClient mongoClient = lyricsFinderModel.connectToMongoDB();
        TimeZone tz = TimeZone.getTimeZone("UTC");
        SimpleDateFormat sdf
                = new SimpleDateFormat(
                "dd-MM-yyyy HH:mm:ss.SSS");
        sdf.setTimeZone(tz);
        mobile_request_timestamp = sdf.format(new Date());
        //response.setContentType("text/html");

        //String androidRequest = "http://localhost:8080/getLyrics?artistName=<artistName>&songName=<songName>&phoneBrand=<phoneBrand>&phoneDevice=<phoneDevice>";

        String request_artistName = request.getParameter("artistName");
        String request_songName = request.getParameter("songName");
        String phoneBrand = request.getParameter("phoneBrand");
        String phoneDevice = request.getParameter("phoneDevice");
        String api_key = "4794d71e3256361ba03a768912556bc9";
        String lyrics = "";

        String apiURLString = "https://api.vagalume.com.br/search.php?art="
                + request_artistName + "&mus="
                + request_songName + "&apikey="
                + api_key;

        MongoDatabase LyricsFinderDB = mongoClient.getDatabase("LyricsFinderDB");

        MongoCollection<Document> mobileCollection = LyricsFinderDB.getCollection("MOBILE");

        MongoCollection<Document> apiCollection = LyricsFinderDB.getCollection("API");

        api_request_timestamp = sdf.format(new Date());
        String jsonAPIReply = lyricsFinderModel.fetchAPI(apiURLString);

        api_response_timestamp = sdf.format(new Date());

        JSONObject jsonObject = new JSONObject(jsonAPIReply);

        JSONObject artistInfo = jsonObject.getJSONObject("art");

        response_artistName = artistInfo.getString("name");


        JSONArray jsonArray = jsonObject.getJSONArray("mus"); // notice that `"posts": [...]`

        for (int i = 0; i < jsonArray.length(); i++) {
            String lyrics_line = jsonArray.getJSONObject(i).getString("text");
            lyrics = lyrics + lyrics_line;
            response_songName = jsonArray.getJSONObject(i).getString("name");
        }

        try {
            latency = sdf.parse(api_response_timestamp).getTime() - sdf.parse(api_request_timestamp).getTime();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        API api = new API(api_request_timestamp, request_songName, request_artistName, response_songName, response_artistName, lyrics, api_response_timestamp, statusCode, latency);
        lyricsFinderModel.apiInsertOne(api, apiCollection);

        ResponseMessage responseMessage = new ResponseMessage(response_artistName, response_songName, lyrics);

        // https://www.baeldung.com/servlet-json-response

        PrintWriter out = response.getWriter();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        mobile_response_timestamp = sdf.format(new Date());

        try {
            latency = sdf.parse(mobile_response_timestamp).getTime() - sdf.parse(mobile_request_timestamp).getTime();
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        Mobile mobile = new Mobile(phoneDevice, phoneBrand, mobile_request_timestamp, request_songName, request_artistName, response_songName, response_artistName, lyrics, mobile_response_timestamp, latency, statusCode);
        lyricsFinderModel.mobileInsertOne(mobile, mobileCollection);

        out.print(responseMessage);
        out.flush();

        // Hello
        //PrintWriter out = response.getWriter();
        //out.println("<html><body>");
        //out.println("<h1>" + message + "</h1>");
        //out.println("</body></html>");


    }

    public void destroy() {
    }
}